package assignment3;

import java.util.Set;
import java.util.ArrayList;
import java.util.Stack;

public class Spot {
   private String word;

    public Spot(String word){
        this.word = word;
    }

    @Override
    public boolean equals(Object obj){
        if(obj == null){
            return false;
        }
        if(obj.getClass() != this.getClass()){
            return false;
        }
        Spot other = (Spot) obj;
        return this.word.equals(other.word);
    }

    public String getWord(){
        return this.word;
    }

    public int getDifference(String other){
        int count = 0;
        if(this.word.length() != other.length()){
            throw new IndexOutOfBoundsException("they're different lengths this is bad");
        }

        for(int i = 0;i < this.word.length();i++){
            if(this.word.charAt(i) != other.charAt(i)){
                count++;
            }
        }
        return count;
    }
    boolean containsSpot(Set<Spot> set, Spot check){
        for(Spot str : set){
            if(str.equals(check)){
                return true;
            }
        }
        return false;
    }

    //returns all of the words that are one letter off of the current word
    //won't return any words/ spots that have already been visited
    public Stack<Spot> getConnections (Set<String> dict, Set<Spot> visited){
        Stack<Spot> connections = new Stack<>();

        for(String str : dict){
           if(this.getDifference(str) == 1){
               Spot temp = new Spot(str);
               if(!temp.containsSpot(visited, temp)) {
                   connections.push(temp);
               }
           }
        }
        return connections;
    }





}
