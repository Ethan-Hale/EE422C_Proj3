package assignment3;
/* WORD LADDER Main.java
 * EE422C Project 3 submission by
 * Replace <...> with your actual data.
 * <Nikhil Reddy>
 * <nr25547>
 * <17620>
 * <Ethan Hale>
 * <erh2656>
 * <17620>
 * Slip days used: <0>
 * Git URL:
 * Fall 2023
 */


import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.lang.reflect.Array;
import java.util.*;

public class Main {



    // static variables and constants only here.

    static Set<String> dict;

    public static void main(String[] args) throws Exception {

        Scanner kb;	// input Scanner for commands
        PrintStream ps;	// output file, for student testing and grading only
        // If arguments are specified, read/write from/to files instead of Std IO.
        if (args.length != 0) {
            kb = new Scanner(new File(args[0]));
            ps = new PrintStream(new File(args[1]));
            System.setOut(ps);			// redirect output to ps
        } else {
            kb = new Scanner(System.in);// default input from Stdin
            ps = System.out;			// default output to Stdout
        }
        initialize();
        ArrayList<String> input = parse(kb);
        while(input != null){

            ArrayList<String> resultBFS = getWordLadderBFS(input.get(0), input.get(1));
            printLadder(resultBFS);


            ArrayList<String> resultDFS = getWordLadderDFS(input.get(0), input.get(1));
            printLadder(resultDFS);

            input = parse(kb);
        }


        // TODO methods to read in words, output ladder
    }

    //Initialize Dict as a hashset using makeDict
    public static void initialize() {
        // initialize your static variables or constants here.
        // We will call this method before running our JUNIT tests.  So call it
        // only once at the start of main.
        dict = new HashSet<String>(makeDictionary());
    }

    /**
     * @param keyboard Scanner connected to System.in
     * @return ArrayList of Strings containing start word and end word.
     * If command is /quit, return empty ArrayList.
     */
    public static ArrayList<String> parse(Scanner keyboard) {
        // TO DO
        ArrayList<String> res = new ArrayList<>();
        String w1 = keyboard.next();
        if(w1.equals("/quit")){
            return null;
        }
        res.add(w1.toUpperCase());
        w1 = keyboard.next();
        res.add(w1.toUpperCase());
        return res;
    }

    public static ArrayList<String> getWordLadderDFS(String start, String end) {

        // Returned list should be ordered start to end.  Include start and end.
        // If ladder is empty, return list with just start and end.
        // TODO some code

        DFS d = new DFS(dict);
        ArrayList<String> ladder = d.getLadder(start.toUpperCase(),end.toUpperCase());

        if(!ladder.get(ladder.size()-1).equals(end.toLowerCase())){
            ladder.add(end.toLowerCase());
        }


        return ladder;
    }

    public static ArrayList<String> getWordLadderBFS(String start, String end) {

        // TODO some code
        String[] onlySE = {start.toUpperCase(),end.toUpperCase()};
        if(!dict.contains(start.toUpperCase()) && !dict.contains(end.toUpperCase())){
            ArrayList<String> foo = new ArrayList<>(Arrays.asList(onlySE));
            return foo;
        }
        BFS b = new BFS();
        return b.getBFSLadder(start,end, dict);

        // replace this line later with real return
    }


    public static void printLadder(ArrayList<String> ladder) {
        if(ladder.size() ==2){
            System.out.println("no word ladder can be found between " + ladder.get(0) + " and " + ladder.get(1));
        } else if(ladder.get(2).length() == 3) {
            System.out.println("a " + 0 + "-rung ladder exists between " + ladder.get(0).toLowerCase() + " and " + ladder.get(1).toLowerCase() + ".");
        } else{
            System.out.println("a " + (ladder.size()-2) + "-rung ladder exists between " + ladder.get(0).toLowerCase() + " and " + ladder.get(ladder.size()-1).toLowerCase() + ".");
            for(int i =0; i<ladder.size(); i++){
                System.out.println(ladder.get(i).toLowerCase());
            }
        }

    }
    // TODO
    // Other private static methods here


    /* Do not modify makeDictionary */
    public static Set<String>  makeDictionary () {
        Set<String> words = new HashSet<String>();
        Scanner infile = null;
        try {
            infile = new Scanner (new File("five_letter_words.txt"));
        } catch (FileNotFoundException e) {
            System.out.println("Dictionary File not Found!");
            e.printStackTrace();
            System.exit(1);
        }
        while (infile.hasNext()) {
            words.add(infile.next().toUpperCase());
        }
        return words;
    }
}
