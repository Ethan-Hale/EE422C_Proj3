package assignment3;

import java.util.*;

public class BFS {
    //Node stores essential info, most importantly is visited
    public class Node{
        private String word;            //word
        private Node parent;          //word that called this word


        public Node(String word, Node parent){
            this.word = word.toUpperCase();
            this.parent = parent;
        }

        public Node(String word){
            this.word = word;
            this.parent = null;

        }

        public void setParent(Node parent){
            this.parent = parent;
        }



        public String getWord(){
            return this.word;
        }
        public Node getParent(){
            return this.parent;
        }


        //set the node as visited and add it to the set of visited words
        public void setVis(Map<String, Boolean> x){

            x.put(this.word, true);
        }


    }

    public Queue<Node> q;             //Strings to be visited
    private ArrayList<String> resArr;   //List of final word ladder

    HashMap<String, Boolean> visMap = new HashMap<>() ;

    public BFS(){
        q = new LinkedList<Node>();
        resArr = new ArrayList<>();
    }


    public ArrayList<String> getBFSLadder(String start, String end, Set<String> dict){

        Stack<String> words = new Stack<>();
        ArrayList<String> oneAw = new ArrayList<>(getOneAway(end, dict));
        Node word = new Node(start);
        this.q.add(word);
        word.setVis(visMap);
        if(oneAw.contains(start)){
            String[] onlySE = {start,end, "wow"};
            ArrayList foo = new ArrayList(Arrays.asList(onlySE));
            return foo;
        }

        while(!this.q.isEmpty()){
            Node current = this.q.remove();
            ArrayList<Node> neighbors = getNextWords(current,dict);
            for(Node adjNode:neighbors){
                //Add to queue if not alr visited/ accounting for start word
                if(!(visMap.containsKey(adjNode.getWord())) && !adjNode.getWord().equals(start)){
                    this.q.add(adjNode);
                    adjNode.setVis(visMap);
                }



                //If last word found
                if(adjNode.getWord().equals(end) || oneAw.contains(adjNode.getWord())){
                    if(oneAw.contains(adjNode.getWord())){
                        words.push(end);
                    }
                    //Trace back through parents
                    while(adjNode != null){
                        words.push(adjNode.getWord());
                        adjNode = adjNode.getParent();
                    }

                    //Flip order into result array
                    while(!words.isEmpty()){
                        resArr.add(words.pop().toUpperCase());
                    }


                    return resArr;
                }

            }
        }

        //only reach here if no word ever found
        String[] onlySE = {start,end};
        ArrayList foo = new ArrayList(Arrays.asList(onlySE));
        return foo;
    }




    //Get all words one letter away from the final word, return as an arraylist of strings
    public ArrayList<String> getOneAway(String fin,Set<String> dict){
        char[] letters = "abcdefghijklmnopqrstuvwxyz".toCharArray();
        ArrayList<String> oneAways = new ArrayList<>();
        String temp;
        for(int i = 0; i<fin.length(); i++){
            for(int k = 0; k<letters.length;k++){
                temp = fin.substring(0,i)+ letters[k] + fin.substring(i+1);
                if(!fin.equals(temp) && dict.contains(temp.toUpperCase())){
                    oneAways.add(temp.toUpperCase());
                }
            }
        }
        return oneAways;
    }
    // Get all possible next words, aka find all valid words by replacing only one letter in the parent word
    public ArrayList<Node> getNextWords(Node word, Set<String> dict){
        char[] letters = "abcdefghijklmnopqrstuvwxyz".toCharArray();
        ArrayList<Node> neigh = new ArrayList<>();
        String temp;
        for(int i =0;i<word.getWord().length(); i++){
            for(char c:letters){
                temp = word.getWord().substring(0,i)+ c + word.getWord().substring(i+1);
                if(!word.getWord().equals(temp) && dict.contains(temp.toUpperCase())){
                    neigh.add(new Node(temp, word));

                }
            }
        }

        return neigh;
    }
}
