package assignment3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;

public class DFS {
    static Set<String> dict;


    public DFS (Set<String> dict){
        DFS.dict = dict;
    }

    public boolean doDFS(Spot start, Spot end, ArrayList<Spot> ladder, Set<Spot> visited){
        if(start == null){
            return false;
        }
        visited.add(start);
        ladder.add(start);
        if(start.equals(end)){
            return true;
        } else {
            Stack<Spot> connectionsList = start.getConnections(dict, visited);
            while(!connectionsList.isEmpty()){
                Spot next = connectionsList.pop();
                if(doDFS(next, end, ladder, visited)){
                    return true;
                } else {
                    ladder.remove(next);
                }
            }
        }
        return false;
    }

    public ArrayList<String> getLadder(String startword, String endword){
        ArrayList<Spot> ladder = new ArrayList<>();
        Set<Spot> visited = new HashSet<>();
        Spot start = new Spot(startword);
        Spot end = new Spot(endword);
        ArrayList<String> finishedLadder = new ArrayList<>();

        doDFS(start, end, ladder, visited);

        if(!dict.contains(startword.toUpperCase()) || !dict.contains(endword.toUpperCase())){
            finishedLadder.add(startword);
            finishedLadder.add(endword);
            return finishedLadder;
        }


        for(int i = 0;i < ladder.size();i++){
            finishedLadder.add(i, ladder.get(i).getWord().toLowerCase());
        }

        return finishedLadder;



    }





}
